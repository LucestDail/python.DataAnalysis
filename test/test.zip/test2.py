# -*- coding: utf-8 -*-
"""
Created on Fri Feb 19 14:29:08 2021

@author: dhtmd
"""

base = 1000000
for i in range(0,3):
    base *= 0.7
    
print(base)
